function aiPage()
{ 
    return pageHeader(t('pages.aiTitle'), t('pages.aiSubtitle')) + `
        <div class="card ai-shell"  style="height: 600px;">
            <div class="message-list" id="ai-messages">
                ${state.aiMessages.map(m => `
                    <div class="message ${m.from}">${esc(m.text)}</div>`).join('')}
            </div>
            <div class="chip-row" style="margin:10px 0">
                ${state.data.aiQa.map(qa => `
                    <button class="btn-secondary" onclick="askAi(${esc(JSON.stringify(qa.q))})">${esc(qa.q)}</button>`).join('')}
            </div>
            <div class="ai-input-row">
                <input class="input-field" id="ai-input" onkeydown="if(event.key==='Enter'){event.preventDefault();sendAi()}" placeholder="Ask about your skills, gaps or learning…">
                <button class="btn-teal" onclick="sendAi()">↗</button>
            </div>
        </div>`; 
}

